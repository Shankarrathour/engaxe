/* main.js - render series cards, mobile menu, theme toggle, misc */

document.addEventListener('DOMContentLoaded', function(){
    // render year in footer
    const y = new Date().getFullYear();
    const yearEl = document.getElementById('year');
    if(yearEl) yearEl.textContent = y;
  
    // mobile menu toggle
    const menuToggle = document.getElementById('menuToggle');
    const nav = document.querySelector('.nav');
    if(menuToggle && nav){
      menuToggle.addEventListener('click', () => {
        const isShown = nav.style.display === 'flex';
        nav.style.display = isShown ? 'none' : 'flex';
        nav.style.flexDirection = 'column';
        nav.style.position = 'absolute';
        nav.style.right = '18px';
        nav.style.top = '64px';
        nav.style.padding = '12px';
        nav.style.borderRadius = '10px';
        nav.style.background = 'rgba(255,255,255,0.02)';
        nav.style.boxShadow = '0 16px 44px rgba(8,6,22,0.6)';
      });
      // close on outside click
      document.addEventListener('click', (e) => {
        if(nav.style.display === 'flex' && !nav.contains(e.target) && !menuToggle.contains(e.target)){
          nav.style.display = 'none';
        }
      });
    }
  
    // theme toggle (simple)
    const themeToggle = document.getElementById('themeToggle');
    if(themeToggle){
      themeToggle.addEventListener('click', () => {
        document.body.classList.toggle('light-theme');
      });
    }
  
    // render series cards from APP_DATA
    const seriesList = document.getElementById('seriesList');
    if(seriesList && window.APP_DATA && Array.isArray(window.APP_DATA.series)){
      const frag = document.createDocumentFragment();
      window.APP_DATA.series.forEach((s, idx) => {
        const card = document.createElement('article');
        card.className = 'series-card';
        card.style.animationDelay = (idx * 80) + 'ms';
        card.innerHTML = `
          <a href="series.html?id=${encodeURIComponent(s.id)}" class="card-link" aria-label="${s.title}">
            <img class="series-thumb" data-src="${s.thumbnail}" alt="${s.title}">
            <div class="series-meta">
              <div class="series-title">${s.title}</div>
              <div class="series-creator">${s.creator} • ${s.episodes} eps</div>
              <p class="muted" style="margin-top:8px;font-size:0.95rem;color:var(--muted)">${s.desc}</p>
            </div>
          </a>
        `;
        frag.appendChild(card);
      });
      seriesList.appendChild(frag);
  
      // lazy load images (simple)
      const lazyImgs = document.querySelectorAll('img[data-src]');
      if('IntersectionObserver' in window){
        const io = new IntersectionObserver((entries, obs) => {
          entries.forEach(entry => {
            if(entry.isIntersecting){
              const img = entry.target;
              img.src = img.dataset.src;
              img.removeAttribute('data-src');
              obs.unobserve(img);
            }
          });
        }, {rootMargin:'200px'});
        lazyImgs.forEach(i => io.observe(i));
      } else {
        // fallback: load all
        lazyImgs.forEach(i => { i.src = i.dataset.src; i.removeAttribute('data-src'); });
      }
    }
  
    // demo: play button opens explore (non-functional demo)
    document.querySelectorAll('.play-btn').forEach(b => {
      b.addEventListener('click', (e) => {
        e.preventDefault();
        window.location.href = 'video.html';
      });
    });
  
  });
  