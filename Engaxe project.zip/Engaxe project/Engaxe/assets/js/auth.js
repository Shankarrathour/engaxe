/* auth.js - manages signup/login/logout using localStorage */
(function(){
  window.signup = function(name,email,password){
    const users = JSON.parse(localStorage.getItem('users')||'[]');
    if(users.find(u=>u.email===email)) return { ok:false, msg:'User exists' };
    users.push({ name, email, password });
    localStorage.setItem('users', JSON.stringify(users));
    localStorage.setItem('currentUser', JSON.stringify({ name, email }));
    return { ok:true };
  };
  window.login = function(email,password){
    const users = JSON.parse(localStorage.getItem('users')||'[]');
    const u = users.find(x=>x.email===email && x.password===password);
    if(!u) return { ok:false, msg:'Invalid credentials' };
    localStorage.setItem('currentUser', JSON.stringify({ name: u.name, email: u.email }));
    return { ok:true };
  };
  window.logout = function(){
    localStorage.removeItem('currentUser');
    location.href = 'login.html';
  };
})();
