   document.addEventListener('DOMContentLoaded', function(){

    // ========== USER CHECK ==========
    const currentUser = localStorage.getItem('currentUser');
    const welcome = document.getElementById('welcomeUser');
    if(!currentUser){
      // no login, redirect
      window.location.href = 'login.html';
      return;
    }
  
    // Display greeting
    if(welcome){
      const namePart = currentUser.split('@')[0];
      welcome.innerHTML = `Welcome back, <span style="color:var(--accent-1);">${namePart}</span> 👋`;
    }
  
    // Year in footer
    const y = new Date().getFullYear();
    const yearEl = document.getElementById('year');
    if(yearEl) yearEl.textContent = y;
  
    // Logout button
    const logoutBtn = document.getElementById('logoutBtn');
    if(logoutBtn){
      logoutBtn.addEventListener('click', () => {
        localStorage.removeItem('currentUser');
        alert('You have been logged out.');
        window.location.href = 'login.html';
      });
    }
  
    // ========== CONTINUE WATCHING ==========
    const continueList = document.getElementById('continueList');
    const savedProgress = JSON.parse(localStorage.getItem('watchProgress') || '[]');
  
    if(continueList && savedProgress.length){
      savedProgress.forEach(id => {
        const series = APP_DATA.series.find(s => s.id === id);
        if(series){
          const card = `
            <article class="series-card">
              <a href="series.html?id=${series.id}">
                <img class="series-thumb" src="${series.thumbnail}" alt="${series.title}">
                <div class="series-meta">
                  <div class="series-title">${series.title}</div>
                  <div class="series-creator">${series.creator}</div>
                </div>
              </a>
            </article>`;
          continueList.insertAdjacentHTML('beforeend', card);
        }
      });
    } else if(continueList){
      continueList.innerHTML = `<p class="muted">No progress yet — start watching a series!</p>`;
    }
  
    // ========== RECOMMENDED SERIES ==========
    const recommendList = document.getElementById('recommendList');
    if(recommendList){
      APP_DATA.series.forEach((s, idx) => {
        const card = `
          <article class="series-card" style="animation-delay:${idx*80}ms;">
            <a href="series.html?id=${s.id}">
              <img class="series-thumb" src="${s.thumbnail}" alt="${s.title}">
              <div class="series-meta">
                <div class="series-title">${s.title}</div>
                <div class="series-creator">${s.creator}</div>
                <p class="muted" style="font-size:0.5rem;">⭐ ${s.rating} • ${s.views} views</p>
              </div>
            </a>
          </article>`;
        recommendList.insertAdjacentHTML('beforeend', card);
      });
    }
  
  });
  