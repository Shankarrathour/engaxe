// Engaxe+ Data File (Fully compatible with all pages)

const APP_DATA = {
  series: [
    {
      id: 1,
      title: "Modern Web Development",
      desc: "Master HTML, CSS, and JavaScript from scratch with real-world projects.",
      thumbnail: "assets/images/thumb1.svg",
      banner: "assets/images/thumb1.svg",
      rating: 4.8,
      views: "12.5K",
      creator: "Aarav Patel",
      creatorId: 1,
      creatorAvatar: "assets/images/avatar1.svg",
      episodesList: [
        { id: 1, title: "Introduction to HTML", duration: "8:32", video: "assets/videos/html_intro.mp4" },
        { id: 2, title: "CSS Fundamentals", duration: "12:14", video: "assets/videos/css_basics.mp4" },
        { id: 3, title: "JavaScript Essentials", duration: "15:05", video: "assets/videos/js_intro.mp4" }
      ]
    },
    {
      id: 2,
      title: "UI/UX Design Basics",
      desc: "Learn how to design beautiful and user-friendly interfaces.",
      thumbnail: "assets/images/thumb2.svg",
      banner: "assets/images/thumb2.svg",
      rating: 4.7,
      views: "9.8K",
      creator: "Riya Sharma",
      creatorId: 2,
      creatorAvatar: "assets/images/avatar2.svg",
      episodesList: [
        { id: 1, title: "Principles of Design", duration: "9:20", video: "assets/videos/design_intro.mp4" },
        { id: 2, title: "Color and Typography", duration: "11:03", video: "assets/videos/colors_fonts.mp4" },
        { id: 3, title: "Wireframing & Prototyping", duration: "10:45", video: "assets/videos/wireframe.mp4" }
      ]
    },
    {
      id: 3,
      title: "Python for Beginners",
      desc: "A beginner-friendly guide to Python programming and automation.",
      thumbnail: "assets/images/thumb3.svg",
      banner: "assets/images/thumb3.svg",
      rating: 4.9,
      views: "14.2K",
      creator: "Aarav Patel",
      creatorId: 1,
      creatorAvatar: "assets/images/avatar1.svg",
      episodesList: [
        { id: 1, title: "Python Basics", duration: "7:18", video: "assets/videos/python_intro.mp4" },
        { id: 2, title: "Control Structures", duration: "10:22", video: "assets/videos/control_structures.mp4" },
        { id: 3, title: "Functions & Loops", duration: "13:11", video: "assets/videos/functions.mp4" }
      ]
    }
  ]
};
